# SPDX-License-Identifier: MIT
import torch
import torch.nn as nn
from .blocks import ResBlock1D

class Generator1D(nn.Module):
    def __init__(self, latent_dim=128, out_features=128, hidden=256):
        super().__init__()
        self.net = nn.Sequential(
            ResBlock1D(latent_dim, hidden),
            nn.LeakyReLU(0.2, inplace=True),
            ResBlock1D(hidden, hidden),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(hidden, out_features),
        )

    def forward(self, z):
        return self.net(z)
