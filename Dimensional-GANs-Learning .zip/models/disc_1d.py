# SPDX-License-Identifier: MIT
import torch
import torch.nn as nn
from .blocks import ResBlock1D, maybe_sn

class Discriminator1D(nn.Module):
    def __init__(self, in_features=128, hidden=256, spectral=True):
        super().__init__()
        def lin(i, o): 
            layer = nn.Linear(i, o)
            return maybe_sn(layer, spectral)
        self.net = nn.Sequential(
            lin(in_features, hidden),
            nn.LeakyReLU(0.2, inplace=True),
            lin(hidden, hidden),
            nn.LeakyReLU(0.2, inplace=True),
            lin(hidden, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(1)
