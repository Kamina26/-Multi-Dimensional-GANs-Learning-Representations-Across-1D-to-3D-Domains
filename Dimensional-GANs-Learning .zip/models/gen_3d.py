# SPDX-License-Identifier: MIT
import torch
import torch.nn as nn
from .blocks import ConvBlock3D

class Generator3D(nn.Module):
    def __init__(self, latent_dim=128, base=32, out_shape=(1, 16, 16, 16)):
        super().__init__()
        C, D, H, W = out_shape
        # project latent to a small 3D grid then upsample
        self.fc = nn.Linear(latent_dim, base*4*4*4)
        self.up = nn.Upsample(scale_factor=2, mode='trilinear', align_corners=False)
        self.trunk = nn.Sequential(
            ConvBlock3D(base, base, use_sn=False),
            self.up,
            ConvBlock3D(base, base, use_sn=False),
            self.up,
            ConvBlock3D(base, base, use_sn=False),
            nn.Conv3d(base, C, kernel_size=3, padding=1),
            nn.Tanh(),
        )
        self.out_shape = out_shape

    def forward(self, z):
        x = self.fc(z).view(z.size(0), -1, 4, 4, 4)
        x = self.trunk(x)
        # crop or pad to target shape if needed
        C, D, H, W = self.out_shape
        return x[:, :C, :D, :H, :W]
