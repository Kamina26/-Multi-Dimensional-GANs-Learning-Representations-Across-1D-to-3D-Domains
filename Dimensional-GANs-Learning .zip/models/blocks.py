# SPDX-License-Identifier: MIT
import torch
import torch.nn as nn
import torch.nn.utils.spectral_norm as spectral_norm

def maybe_sn(module: nn.Module, use_sn: bool):
    return spectral_norm(module) if use_sn else module

class ResBlock1D(nn.Module):
    def __init__(self, in_dim, out_dim, hidden=None):
        super().__init__()
        h = hidden or max(in_dim, out_dim)
        self.net = nn.Sequential(
            nn.Linear(in_dim, h),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(h, out_dim),
        )
        self.skip = nn.Identity() if in_dim == out_dim else nn.Linear(in_dim, out_dim)

    def forward(self, x):
        return self.skip(x) + self.net(x)

class ConvBlock3D(nn.Module):
    def __init__(self, in_c, out_c, k=3, s=1, p=1, use_sn=False):
        super().__init__()
        conv = nn.Conv3d(in_c, out_c, k, s, p)
        self.conv = maybe_sn(conv, use_sn)
        self.act = nn.LeakyReLU(0.2, inplace=True)
        self.bn = nn.BatchNorm3d(out_c)

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))
