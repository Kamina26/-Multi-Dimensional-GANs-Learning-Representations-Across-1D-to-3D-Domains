# SPDX-License-Identifier: MIT
import torch
import torch.nn as nn
from .blocks import ConvBlock3D, maybe_sn

class Discriminator3D(nn.Module):
    def __init__(self, in_channels=1, base=32, spectral=True):
        super().__init__()
        def conv(i,o,k=3,s=2,p=1):
            c = nn.Conv3d(i,o,k,s,p)
            return maybe_sn(c, spectral)
        self.net = nn.Sequential(
            conv(in_channels, base),
            nn.LeakyReLU(0.2, inplace=True),
            conv(base, base*2),
            nn.LeakyReLU(0.2, inplace=True),
            conv(base*2, base*4),
            nn.LeakyReLU(0.2, inplace=True),
        )
        self.head = maybe_sn(nn.Conv3d(base*4, 1, kernel_size=4), spectral)

    def forward(self, x):
        h = self.net(x)
        out = self.head(h).flatten(1).mean(1)
        return out
