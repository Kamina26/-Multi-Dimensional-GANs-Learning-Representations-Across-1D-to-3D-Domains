# SPDX-License-Identifier: MIT
import argparse, yaml, numpy as np, torch
from pathlib import Path
from utils.seed import set_seed
from utils.io import load_npy_pair
from models.gen_1d import Generator1D
from models.gen_3d import Generator3D

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', type=str, required=True)
    ap.add_argument('--out', type=str, required=True)
    ap.add_argument('--n', type=int, default=64)
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text())
    set_seed(cfg.get('seed', 42))
    device = torch.device(cfg.get('device', 'cpu'))

    X, _ = load_npy_pair(cfg['data']['root'])

    if X.ndim == 2:
        in_dim = X.shape[1]
        G = Generator1D(cfg['model']['latent_dim'], in_dim, cfg['model'].get('hidden_dim', 256)).to(device)
    else:
        C,D,H,W = X.shape[1:]
        G = Generator3D(cfg['model']['latent_dim'], cfg['model'].get('base_channels', 32), (C,D,H,W)).to(device)

    weights = Path(cfg['data']['root']) / 'weights.pt'
    if weights.exists():
        sdG, _ = torch.load(weights, map_location=device)
        G.load_state_dict(sdG)

    z = torch.randn(args.n, cfg['model']['latent_dim'], device=device)
    with torch.no_grad():
        samples = G(z).cpu().numpy()
    np.save(args.out, samples)
    print(f"Saved {samples.shape} to {args.out}")

if __name__ == "__main__":
    main()
