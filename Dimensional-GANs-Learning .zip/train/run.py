# SPDX-License-Identifier: MIT
import argparse, yaml, numpy as np, torch
from pathlib import Path
from torch import optim
from torch.utils.data import DataLoader
from utils.seed import set_seed
from utils.io import load_npy_pair
from data.builders import make_loader
from train.losses import d_hinge, g_hinge
from train.ema import EMA

from models.gen_1d import Generator1D
from models.disc_1d import Discriminator1D
from models.gen_3d import Generator3D
from models.disc_3d import Discriminator3D

def train_loop(cfg):
    set_seed(cfg.get('seed', 42))
    device = torch.device(cfg.get('device', 'cpu'))

    X, _ = load_npy_pair(cfg['data']['root'])
    loader = make_loader(X, cfg['data']['batch_size'], cfg['data']['num_workers'])

    if X.ndim == 2:
        in_dim = X.shape[1]
        G = Generator1D(cfg['model']['latent_dim'], in_dim, cfg['model'].get('hidden_dim', 256)).to(device)
        D = Discriminator1D(in_dim, cfg['model'].get('hidden_dim', 256), cfg['train'].get('spectral_norm', True)).to(device)
        z_sampler = lambda b: torch.randn(b, cfg['model']['latent_dim'], device=device)
        def to_device(batch): return batch.to(device)
    else:
        N,C,Dd,H,W = X.shape
        G = Generator3D(cfg['model']['latent_dim'], cfg['model'].get('base_channels', 32), (C,Dd,H,W)).to(device)
        D = Discriminator3D(C, cfg['model'].get('base_channels', 32), cfg['train'].get('spectral_norm', True)).to(device)
        z_sampler = lambda b: torch.randn(b, cfg['model']['latent_dim'], device=device)
        def to_device(batch): return batch.to(device)

    optD = optim.AdamW(D.parameters(), lr=cfg['train']['lr_d'], betas=tuple(cfg['train']['betas']), weight_decay=cfg['train']['weight_decay'])
    optG = optim.AdamW(G.parameters(), lr=cfg['train']['lr_g'], betas=tuple(cfg['train']['betas']), weight_decay=cfg['train']['weight_decay'])

    ema = EMA(G, cfg['train']['ema_decay']) if cfg['train'].get('ema', True) else None

    for epoch in range(cfg['train']['epochs']):
        for i, batch in enumerate(loader):
            real = to_device(batch)
            bsz = real.size(0)
            # D step
            for _ in range(cfg['train']['d_steps']):
                z = z_sampler(bsz)
                with torch.no_grad():
                    fake = G(z)
                real_logit = D(real)
                fake_logit = D(fake)
                loss_d = d_hinge(real_logit, fake_logit)
                optD.zero_grad(set_to_none=True)
                loss_d.backward()
                optD.step()
            # G step
            for _ in range(cfg['train']['g_steps']):
                z = z_sampler(bsz)
                fake = G(z)
                fake_logit = D(fake)
                loss_g = g_hinge(fake_logit)
                optG.zero_grad(set_to_none=True)
                loss_g.backward()
                optG.step()
                if ema: ema.update(G)
        print(f"Epoch {epoch+1}/{cfg['train']['epochs']} | d={loss_d.item():.4f} g={loss_g.item():.4f}")
    # Save final weights (EMA if available)
    outdir = Path(cfg['data']['root'])
    outdir.mkdir(parents=True, exist_ok=True)
    torch.save((G.state_dict(), D.state_dict()), outdir / 'weights.pt')
    if ema:
        G_ema = type(G)().__class__ if hasattr(G, '__class__') else None
    return 0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', type=str, required=True)
    args = ap.parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text())
    train_loop(cfg)

if __name__ == "__main__":
    main()
