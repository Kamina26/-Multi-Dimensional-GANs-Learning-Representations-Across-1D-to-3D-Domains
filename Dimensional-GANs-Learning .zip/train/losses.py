# SPDX-License-Identifier: MIT
import torch

def d_hinge(real_logits, fake_logits):
    loss_real = torch.relu(1. - real_logits).mean()
    loss_fake = torch.relu(1. + fake_logits).mean()
    return loss_real + loss_fake

def g_hinge(fake_logits):
    return -fake_logits.mean()
