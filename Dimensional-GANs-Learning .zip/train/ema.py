# SPDX-License-Identifier: MIT
import torch

class EMA:
    def __init__(self, model, decay=0.999):
        self.decay = decay
        self.shadow = {n: p.clone().detach() for n,p in model.state_dict().items()}

    @torch.no_grad()
    def update(self, model):
        for n, p in model.state_dict().items():
            self.shadow[n].mul_(self.decay).add_(p, alpha=1.0 - self.decay)

    @torch.no_grad()
    def copy_to(self, model):
        model.load_state_dict(self.shadow, strict=True)
