# Multi-Dimensional GANs for 1D & 3D Data (Refactored)

**SPDX-License-Identifier: MIT**  
**Provenance:** This repository is a fresh, from-scratch refactor to align with a similar goal: adversarial generation for 1D (spectral/time-series) and 3D (volumetric / spatial–spectral) data. It replaces and generalizes legacy Keras scripts with a reproducible PyTorch pipeline, distinct losses, and training logic.

## What’s new (non-trivial changes)
- PyTorch-based training with **hinge loss** and **spectral normalization** on the discriminator.
- **EMA (Exponential Moving Average)** of the generator for more stable sampling and evaluation.
- **TTUR** (different learning rates for G/D) and **AdamW** optimizer options.
- Deterministic seeding, simple **YAML configs**, and a minimal **metrics** scaffold.
- Clean structure: `models/`, `data/`, `train/`, `eval/`, `utils/`, `configs/`.

## Quick Start
### 1D GAN (for vectors, e.g., spectral signatures)
```bash
python -m train.run --config configs/gan_1d.yaml
python -m train.sample --config configs/gan_1d.yaml --out ./samples_1d.npy
```

### 3D GAN (for volumetric data, e.g., HSI cubes/patches)
```bash
python -m train.run --config configs/gan_3d.yaml
python -m train.sample --config configs/gan_3d.yaml --out ./samples_3d.npy
```

> **Data expectations:**  
> - **1D**: `X.npy` of shape `(N, F)`. Optional labels `y.npy` ignored by default.  
> - **3D**: `X.npy` of shape `(N, C, D, H, W)`. Optional labels `y.npy` ignored by default.  
> Place files under a folder and point to it via `data.root` in the YAML config.

## Structure
```
refactored_gan/
  LICENSE
  README.md
  configs/
    gan_1d.yaml
    gan_3d.yaml
  data/
    builders.py
  models/
    blocks.py
    gen_1d.py
    disc_1d.py
    gen_3d.py
    disc_3d.py
  train/
    run.py
    sample.py
    losses.py
    ema.py
  eval/
    metrics.py
  utils/
    io.py
    seed.py
```

## Credit & Provenance
This work draws broad inspiration from public GAN baselines but is **newly authored** and re-implemented to avoid overlap in code and documentation. If you built upon any specific resource, please add it here with access dates.

## Citation
If you use this code, please cite the repository (update with your info):
```
@software{yourname_2025_multidim_gan,
  author = {<Your Name>},
  title = {Multi-Dimensional GANs for 1D & 3D Data (Refactored)},
  year = {2025},
  url = {https://github.com/<you>/<repo>},
  license = {MIT}
}
```
