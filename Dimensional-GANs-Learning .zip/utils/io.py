# SPDX-License-Identifier: MIT
from pathlib import Path
import numpy as np

def load_npy_pair(root: str):
    rootp = Path(root)
    X = np.load(rootp / "X.npy")
    y_path = rootp / "y.npy"
    y = np.load(y_path) if y_path.exists() else None
    return X, y
