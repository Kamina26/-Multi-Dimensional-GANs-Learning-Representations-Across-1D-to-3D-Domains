# SPDX-License-Identifier: MIT
from torch.utils.data import Dataset, DataLoader
from pathlib import Path
import numpy as np
import torch

class ArrayDataset1D(Dataset):
    def __init__(self, X: np.ndarray):
        assert X.ndim == 2, "1D dataset expects shape (N, F)"
        self.X = X.astype(np.float32)

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        x = self.X[idx]  # (F,)
        return torch.from_numpy(x)

class ArrayDataset3D(Dataset):
    def __init__(self, X: np.ndarray):
        # Expect (N, C, D, H, W)
        assert X.ndim == 5, "3D dataset expects shape (N, C, D, H, W)"
        self.X = X.astype(np.float32)

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        x = self.X[idx]  # (C, D, H, W)
        return torch.from_numpy(x)

def make_loader(X: np.ndarray, batch_size: int, workers: int):
    if X.ndim == 2:
        ds = ArrayDataset1D(X)
    elif X.ndim == 5:
        ds = ArrayDataset3D(X)
    else:
        raise ValueError(f"Unsupported data shape: {X.shape}")
    return DataLoader(ds, batch_size=batch_size, shuffle=True, num_workers=workers, drop_last=True)
