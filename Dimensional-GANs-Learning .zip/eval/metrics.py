# SPDX-License-Identifier: MIT
# Placeholder for precision/recall and FID-like surrogates based on an encoder.
# Implement domain-appropriate features, e.g., 1D CNN encoder for spectra,
# or 3D CNN encoder for volumes, then compute feature distances.
